exports.handler = async () => ({ statusCode: 503, body: 'Lambda code not yet deployed by CI/CD.' });
